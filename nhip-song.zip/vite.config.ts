import { defineConfig } from "vite";
import preact from "@preact/preset-vite";

export default defineConfig({
  plugins: [preact()],
  build: { outDir: "dist", target: "es2020", sourcemap: false },
  test: { globals: true, environment: "node", include: ["test/**/*.test.ts"] },
} as any);
